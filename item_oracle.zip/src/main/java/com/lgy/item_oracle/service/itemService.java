package com.lgy.item_oracle.service;

import org.springframework.ui.Model;

public interface itemService {
	public void execute(Model model);
}
