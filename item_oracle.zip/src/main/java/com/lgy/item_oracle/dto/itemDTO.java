package com.lgy.item_oracle.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class itemDTO {
	private String name;
	private int price;
	private String description;
}
